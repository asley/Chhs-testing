<?php
// Test reporting cycles query
include '../../gibbon.php';

if (!isActionAccessible($guid, $connection2, '/modules/GradeAnalytics/studentAveragesRanking.php')) {
    die('Access denied');
}

use Gibbon\Module\GradeAnalytics\GradeAnalyticsGateway;

$gateway = $container->get(GradeAnalyticsGateway::class);
$gibbonSchoolYearID = $session->get('gibbonSchoolYearID');

echo "<h2>Testing Reporting Cycles (Terms)</h2>";
echo "<p>School Year ID: $gibbonSchoolYearID</p>";

// Check if reporting cycles exist
echo "<h3>Reporting Cycles in Database:</h3>";
$sql = "SELECT * FROM gibbonReportingCycle WHERE gibbonSchoolYearID = :gibbonSchoolYearID ORDER BY sequenceNumber";
$result = $connection2->prepare($sql);
$result->execute(['gibbonSchoolYearID' => $gibbonSchoolYearID]);
$cycles = $result->fetchAll();

if (count($cycles) > 0) {
    echo "<table border='1' cellpadding='5'>";
    echo "<tr><th>ID</th><th>Name</th><th>Short Name</th><th>Sequence</th><th>Date Start</th><th>Date End</th></tr>";
    foreach ($cycles as $cycle) {
        echo "<tr>";
        echo "<td>".$cycle['gibbonReportingCycleID']."</td>";
        echo "<td>".htmlspecialchars($cycle['name'])."</td>";
        echo "<td>".htmlspecialchars($cycle['nameShort'])."</td>";
        echo "<td>".$cycle['sequenceNumber']."</td>";
        echo "<td>".$cycle['dateStart']."</td>";
        echo "<td>".$cycle['dateEnd']."</td>";
        echo "</tr>";
    }
    echo "</table>";
} else {
    echo "<p style='color: red;'>No reporting cycles found for this school year!</p>";
}

// Check if Internal Assessment columns have reporting cycle IDs
echo "<h3>Internal Assessment Columns with Reporting Cycles:</h3>";
$sql2 = "SELECT
    iac.gibbonInternalAssessmentColumnID,
    iac.name,
    iac.gibbonReportingCycleID,
    rc.name as cycleName,
    c.name as courseName
FROM gibbonInternalAssessmentColumn iac
LEFT JOIN gibbonReportingCycle rc ON iac.gibbonReportingCycleID = rc.gibbonReportingCycleID
JOIN gibbonCourseClass cc ON iac.gibbonCourseClassID = cc.gibbonCourseClassID
JOIN gibbonCourse c ON cc.gibbonCourseID = c.gibbonCourseID
WHERE c.gibbonSchoolYearID = :gibbonSchoolYearID
LIMIT 20";

$result2 = $connection2->prepare($sql2);
$result2->execute(['gibbonSchoolYearID' => $gibbonSchoolYearID]);
$assessments = $result2->fetchAll();

if (count($assessments) > 0) {
    echo "<table border='1' cellpadding='5'>";
    echo "<tr><th>Assessment Column</th><th>Course</th><th>Reporting Cycle ID</th><th>Cycle Name</th></tr>";
    foreach ($assessments as $assessment) {
        $cycleInfo = $assessment['gibbonReportingCycleID'] ?
            $assessment['gibbonReportingCycleID']." - ".$assessment['cycleName'] :
            '<span style="color: red;">Not assigned</span>';
        echo "<tr>";
        echo "<td>".htmlspecialchars($assessment['name'])."</td>";
        echo "<td>".htmlspecialchars($assessment['courseName'])."</td>";
        echo "<td>".$cycleInfo."</td>";
        echo "</tr>";
    }
    echo "</table>";

    // Count how many have cycles vs don't
    $withCycle = 0;
    $withoutCycle = 0;
    foreach ($assessments as $a) {
        if ($a['gibbonReportingCycleID']) {
            $withCycle++;
        } else {
            $withoutCycle++;
        }
    }
    echo "<p><strong>Summary (first 20):</strong> $withCycle with reporting cycle, $withoutCycle without</p>";
} else {
    echo "<p style='color: red;'>No internal assessment columns found!</p>";
}

// Check the structure of the Internal Assessment Column table
echo "<h3>Table Structure Check:</h3>";
$sql3 = "SHOW COLUMNS FROM gibbonInternalAssessmentColumn LIKE '%report%'";
$result3 = $connection2->prepare($sql3);
$result3->execute();
$columns = $result3->fetchAll();

if (count($columns) > 0) {
    echo "<p style='color: green;'>✓ gibbonReportingCycleID column exists in gibbonInternalAssessmentColumn table</p>";
    echo "<pre>";
    print_r($columns);
    echo "</pre>";
} else {
    echo "<p style='color: red;'>✗ gibbonReportingCycleID column does NOT exist in gibbonInternalAssessmentColumn table</p>";
    echo "<p>This column may need to be added via database migration.</p>";
}
