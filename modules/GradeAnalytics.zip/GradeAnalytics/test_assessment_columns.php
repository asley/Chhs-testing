<?php
// Test assessment columns query
include '../../gibbon.php';

if (!isActionAccessible($guid, $connection2, '/modules/GradeAnalytics/studentAveragesRanking.php')) {
    die('Access denied');
}

use Gibbon\Module\GradeAnalytics\GradeAnalyticsGateway;

$gateway = $container->get(GradeAnalyticsGateway::class);
$gibbonSchoolYearID = $session->get('gibbonSchoolYearID');

echo "<h2>Testing Assessment Columns</h2>";
echo "<p>School Year ID: $gibbonSchoolYearID</p>";

// Test the gateway method
echo "<h3>Using Gateway Method (selectAssessmentColumns):</h3>";
try {
    $result = $gateway->selectAssessmentColumns($gibbonSchoolYearID);
    $count = $result->rowCount();
    echo "<p>Rows returned: $count</p>";

    if ($count > 0) {
        echo "<table border='1' cellpadding='5'>";
        echo "<tr><th>ID</th><th>Assessment Name</th></tr>";
        foreach ($result as $row) {
            echo "<tr>";
            echo "<td>".$row['value']."</td>";
            echo "<td>".htmlspecialchars($row['name'])."</td>";
            echo "</tr>";
        }
        echo "</table>";
    } else {
        echo "<p style='color: red;'>No assessment columns found!</p>";
    }
} catch (Exception $e) {
    echo "<p style='color: red;'>Error: ".$e->getMessage()."</p>";
}

// Test direct SQL query
echo "<h3>Direct SQL Query:</h3>";
$sql = "SELECT DISTINCT
            iac.gibbonInternalAssessmentColumnID,
            iac.name,
            c.name as courseName,
            COUNT(*) as usage_count
        FROM gibbonInternalAssessmentColumn iac
        JOIN gibbonCourseClass cc ON iac.gibbonCourseClassID = cc.gibbonCourseClassID
        JOIN gibbonCourse c ON cc.gibbonCourseID = c.gibbonCourseID
        WHERE c.gibbonSchoolYearID = :gibbonSchoolYearID
        AND iac.name IS NOT NULL
        AND iac.name != ''
        GROUP BY iac.gibbonInternalAssessmentColumnID, iac.name, c.name
        ORDER BY iac.name
        LIMIT 50";

$result = $connection2->prepare($sql);
$result->execute(['gibbonSchoolYearID' => $gibbonSchoolYearID]);
$assessments = $result->fetchAll();

echo "<p>Total unique assessment columns found: ".count($assessments)."</p>";

if (count($assessments) > 0) {
    echo "<table border='1' cellpadding='5' style='border-collapse: collapse;'>";
    echo "<tr><th>Assessment ID</th><th>Assessment Name</th><th>Course</th><th>Usage Count</th></tr>";
    foreach ($assessments as $row) {
        echo "<tr>";
        echo "<td>".$row['gibbonInternalAssessmentColumnID']."</td>";
        echo "<td>".htmlspecialchars($row['name'])."</td>";
        echo "<td>".htmlspecialchars($row['courseName'])."</td>";
        echo "<td>".$row['usage_count']."</td>";
        echo "</tr>";
    }
    echo "</table>";
} else {
    echo "<p style='color: red;'>No assessment columns found in database!</p>";

    // Check if there are any assessment columns at all
    $checkSQL = "SELECT COUNT(*) as total FROM gibbonInternalAssessmentColumn";
    $checkResult = $connection2->prepare($checkSQL);
    $checkResult->execute();
    $total = $checkResult->fetch();
    echo "<p>Total assessment columns in entire database: ".$total['total']."</p>";

    // Check current school year
    $yearSQL = "SELECT * FROM gibbonSchoolYear WHERE gibbonSchoolYearID = :gibbonSchoolYearID";
    $yearResult = $connection2->prepare($yearSQL);
    $yearResult->execute(['gibbonSchoolYearID' => $gibbonSchoolYearID]);
    $yearInfo = $yearResult->fetch();
    echo "<p>Current School Year: ".htmlspecialchars($yearInfo['name'])." (Status: ".$yearInfo['status'].")</p>";
}

// Show sample data from gibbonInternalAssessmentColumn
echo "<h3>Sample Assessment Columns (any year):</h3>";
$sampleSQL = "SELECT iac.*, c.name as courseName, c.gibbonSchoolYearID
              FROM gibbonInternalAssessmentColumn iac
              JOIN gibbonCourseClass cc ON iac.gibbonCourseClassID = cc.gibbonCourseClassID
              JOIN gibbonCourse c ON cc.gibbonCourseID = c.gibbonCourseID
              LIMIT 10";
$sampleResult = $connection2->prepare($sampleSQL);
$sampleResult->execute();
$samples = $sampleResult->fetchAll();

if (count($samples) > 0) {
    echo "<table border='1' cellpadding='5' style='border-collapse: collapse;'>";
    echo "<tr><th>Column ID</th><th>Name</th><th>Type</th><th>Course</th><th>School Year ID</th></tr>";
    foreach ($samples as $row) {
        echo "<tr>";
        echo "<td>".$row['gibbonInternalAssessmentColumnID']."</td>";
        echo "<td>".htmlspecialchars($row['name'])."</td>";
        echo "<td>".htmlspecialchars($row['type'])."</td>";
        echo "<td>".htmlspecialchars($row['courseName'])."</td>";
        echo "<td>".$row['gibbonSchoolYearID']."</td>";
        echo "</tr>";
    }
    echo "</table>";
}
