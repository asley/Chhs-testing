<?php
// Debug script to test student averages query
include '../../config.php';

use Gibbon\Module\GradeAnalytics\GradeAnalyticsGateway;

// Get container
$container = $gibbon->getContainer();
$gateway = $container->get(GradeAnalyticsGateway::class);

// Get current school year
$gibbonSchoolYearID = $_SESSION[$guid]['gibbonSchoolYearID'] ?? null;

echo "<h2>Debug: Student Averages Query</h2>";
echo "<p>School Year ID: " . $gibbonSchoolYearID . "</p>";

// First, check if we have any internal assessment data
$testSQL = "SELECT COUNT(*) as count FROM gibbonInternalAssessmentEntry";
$testResult = $pdo->select($testSQL);
$count = $testResult->fetch();
echo "<p>Total Internal Assessment Entries: " . $count['count'] . "</p>";

// Check for numeric grades
$numericSQL = "SELECT COUNT(*) as count
               FROM gibbonInternalAssessmentEntry
               WHERE attainmentValue IS NOT NULL
               AND TRIM(attainmentValue) != ''
               AND attainmentValue REGEXP '^[0-9]+(\\.[0-9]+)?\$'";
$numericResult = $pdo->select($numericSQL);
$numericCount = $numericResult->fetch();
echo "<p>Numeric Grade Entries: " . $numericCount['count'] . "</p>";

// Check sample grades
$sampleSQL = "SELECT attainmentValue, COUNT(*) as count
              FROM gibbonInternalAssessmentEntry
              WHERE attainmentValue IS NOT NULL
              AND TRIM(attainmentValue) != ''
              GROUP BY attainmentValue
              LIMIT 20";
$sampleResult = $pdo->select($sampleSQL);
echo "<h3>Sample Grades in Database:</h3>";
echo "<table border='1' cellpadding='5'>";
echo "<tr><th>Grade Value</th><th>Count</th></tr>";
foreach ($sampleResult as $row) {
    echo "<tr><td>" . htmlspecialchars($row['attainmentValue']) . "</td><td>" . $row['count'] . "</td></tr>";
}
echo "</table>";

// Try the full query
try {
    echo "<h3>Testing Full Query:</h3>";
    $filters = [];
    $students = $gateway->selectStudentAverages($gibbonSchoolYearID, $filters);
    echo "<p>Rows returned: " . $students->rowCount() . "</p>";

    if ($students->rowCount() > 0) {
        echo "<h3>Sample Results:</h3>";
        echo "<table border='1' cellpadding='5'>";
        echo "<tr><th>Student</th><th>Form Group</th><th>Year Group</th><th>Courses</th><th>Average</th></tr>";
        $count = 0;
        foreach ($students as $student) {
            if ($count++ >= 10) break;
            echo "<tr>";
            echo "<td>" . htmlspecialchars($student['preferredName'] . ' ' . $student['surname']) . "</td>";
            echo "<td>" . htmlspecialchars($student['formGroup']) . "</td>";
            echo "<td>" . htmlspecialchars($student['yearGroup']) . "</td>";
            echo "<td>" . $student['totalCourses'] . "</td>";
            echo "<td>" . number_format($student['finalAverage'], 2) . "%</td>";
            echo "</tr>";
        }
        echo "</table>";
    }
} catch (Exception $e) {
    echo "<p style='color: red;'>Error: " . htmlspecialchars($e->getMessage()) . "</p>";
}

// Check course enrollments
$enrollmentSQL = "SELECT COUNT(DISTINCT s.gibbonPersonID) as studentCount
                  FROM gibbonPerson s
                  JOIN gibbonStudentEnrolment se ON se.gibbonPersonID = s.gibbonPersonID
                  JOIN gibbonCourseClassPerson ccp ON ccp.gibbonPersonID = s.gibbonPersonID
                  WHERE s.status = 'Full'
                  AND ccp.role = 'Student'
                  AND se.gibbonSchoolYearID = :gibbonSchoolYearID";
$enrollmentResult = $pdo->select($enrollmentSQL, ['gibbonSchoolYearID' => $gibbonSchoolYearID]);
$enrollmentCount = $enrollmentResult->fetch();
echo "<p>Students enrolled in courses: " . $enrollmentCount['studentCount'] . "</p>";
