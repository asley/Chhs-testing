<?php
$version = '1.0.0';
$releaseDate = '2024-03-23';
$minimumGibbonVersion = 'v24.0.00';
$maximumGibbonVersion = 'v25.0.00';

$dependencies = array(
    'Core' => array(
        'minimum' => 'v24.0.00',
        'maximum' => 'v25.0.00'
    )
); 