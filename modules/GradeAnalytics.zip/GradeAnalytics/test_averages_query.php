<?php
// Test averages query
include '../../gibbon.php';

if (!isActionAccessible($guid, $connection2, '/modules/GradeAnalytics/studentAveragesRanking.php')) {
    die('Access denied');
}

echo "<h2>Testing Student Averages Query</h2>";

$gibbonSchoolYearID = $session->get('gibbonSchoolYearID');
echo "<p>School Year ID: $gibbonSchoolYearID</p>";

// First, check sample grades
echo "<h3>Sample Internal Assessment Grades:</h3>";
$sampleSQL = "SELECT me.attainmentValue, COUNT(*) as count
              FROM gibbonInternalAssessmentEntry me
              JOIN gibbonInternalAssessmentColumn iac ON me.gibbonInternalAssessmentColumnID = iac.gibbonInternalAssessmentColumnID
              JOIN gibbonCourseClass cc ON iac.gibbonCourseClassID = cc.gibbonCourseClassID
              JOIN gibbonCourse c ON cc.gibbonCourseID = c.gibbonCourseID
              WHERE c.gibbonSchoolYearID = :gibbonSchoolYearID
              AND me.attainmentValue IS NOT NULL
              AND TRIM(me.attainmentValue) != ''
              GROUP BY me.attainmentValue
              ORDER BY count DESC
              LIMIT 20";

$result = $connection2->prepare($sampleSQL);
$result->execute(['gibbonSchoolYearID' => $gibbonSchoolYearID]);
$samples = $result->fetchAll();

echo "<table border='1' cellpadding='5' style='border-collapse: collapse;'>";
echo "<tr><th>Grade Value</th><th>Count</th><th>Is Numeric?</th></tr>";
foreach ($samples as $row) {
    $isNumeric = preg_match('/^[0-9]+(\.[0-9]+)?$/', $row['attainmentValue']) ? 'Yes' : 'No';
    echo "<tr>";
    echo "<td>" . htmlspecialchars($row['attainmentValue']) . "</td>";
    echo "<td>" . $row['count'] . "</td>";
    echo "<td>" . $isNumeric . "</td>";
    echo "</tr>";
}
echo "</table>";

// Now try the averages query without the REGEXP filter
echo "<h3>Test Query (without REGEXP filter):</h3>";
$testSQL = "SELECT
    s.gibbonPersonID,
    s.preferredName,
    s.surname,
    fg.name as formGroup,
    yg.name as yearGroup,
    COUNT(DISTINCT c.gibbonCourseID) as totalCourses,
    COUNT(me.gibbonInternalAssessmentEntryID) as totalAssessments,
    AVG(CAST(me.attainmentValue AS DECIMAL(10,2))) as rawAverage
FROM gibbonPerson s
JOIN gibbonStudentEnrolment se ON se.gibbonPersonID = s.gibbonPersonID
JOIN gibbonFormGroup fg ON fg.gibbonFormGroupID = se.gibbonFormGroupID
JOIN gibbonYearGroup yg ON yg.gibbonYearGroupID = se.gibbonYearGroupID
JOIN gibbonCourseClassPerson ccp ON ccp.gibbonPersonID = s.gibbonPersonID
JOIN gibbonCourseClass cc ON cc.gibbonCourseClassID = ccp.gibbonCourseClassID
JOIN gibbonCourse c ON c.gibbonCourseID = cc.gibbonCourseID
JOIN gibbonInternalAssessmentColumn iac ON iac.gibbonCourseClassID = cc.gibbonCourseClassID
JOIN gibbonInternalAssessmentEntry me ON me.gibbonPersonIDStudent = s.gibbonPersonID
    AND me.gibbonInternalAssessmentColumnID = iac.gibbonInternalAssessmentColumnID
WHERE s.status = 'Full'
AND ccp.role = 'Student'
AND se.gibbonSchoolYearID = :gibbonSchoolYearID
AND c.gibbonSchoolYearID = :gibbonSchoolYearID
AND me.attainmentValue IS NOT NULL
AND TRIM(me.attainmentValue) != ''
GROUP BY s.gibbonPersonID, s.preferredName, s.surname, fg.name, yg.name
LIMIT 10";

$result = $connection2->prepare($testSQL);
$result->execute(['gibbonSchoolYearID' => $gibbonSchoolYearID]);
$students = $result->fetchAll();

echo "<p>Rows returned: " . count($students) . "</p>";

if (count($students) > 0) {
    echo "<table border='1' cellpadding='5' style='border-collapse: collapse;'>";
    echo "<tr><th>Student</th><th>Form Group</th><th>Year Group</th><th>Courses</th><th>Assessments</th><th>Raw Average</th></tr>";
    foreach ($students as $row) {
        echo "<tr>";
        echo "<td>" . htmlspecialchars($row['preferredName'] . ' ' . $row['surname']) . "</td>";
        echo "<td>" . htmlspecialchars($row['formGroup']) . "</td>";
        echo "<td>" . htmlspecialchars($row['yearGroup']) . "</td>";
        echo "<td>" . $row['totalCourses'] . "</td>";
        echo "<td>" . $row['totalAssessments'] . "</td>";
        echo "<td>" . ($row['rawAverage'] ? number_format($row['rawAverage'], 2) : 'N/A') . "</td>";
        echo "</tr>";
    }
    echo "</table>";
} else {
    echo "<p style='color: red;'>No data found!</p>";

    // Check enrollment
    $enrollSQL = "SELECT COUNT(DISTINCT s.gibbonPersonID) as count
                  FROM gibbonPerson s
                  JOIN gibbonStudentEnrolment se ON se.gibbonPersonID = s.gibbonPersonID
                  WHERE s.status = 'Full'
                  AND se.gibbonSchoolYearID = :gibbonSchoolYearID";
    $result = $connection2->prepare($enrollSQL);
    $result->execute(['gibbonSchoolYearID' => $gibbonSchoolYearID]);
    $enrollCount = $result->fetch();
    echo "<p>Total enrolled students: " . $enrollCount['count'] . "</p>";
}
